import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Properties;
import java.util.Scanner;

// ================= USER CLASS =================

class User {

    private String name;
    private int age;
    private double weight;
    private double height;
    private String fitnessGoal;

    public User(String name, int age, double weight,
                double height, String fitnessGoal) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.fitnessGoal = fitnessGoal;
    }

    public double calculateBMI() {
        double heightInMeters = height / 100;
        return weight / (heightInMeters * heightInMeters);
    }

    public String getFitnessGoal() {
        return fitnessGoal;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }

    public void displayProfile() {
        double bmi = calculateBMI();

        System.out.println("\n=====================================");
        System.out.println("         FITNESS PROFILE");
        System.out.println("=====================================");

        System.out.println("Name          : " + name);
        System.out.println("Age           : " + age);
        System.out.println("Weight        : " + weight + " kg");
        System.out.println("Height        : " + height + " cm");
        System.out.println("Fitness Goal  : " + fitnessGoal);

        System.out.printf("BMI           : %.2f%n", bmi);

        if (age < 20) {
            System.out.println("BMI Category  : Not displayed");
            System.out.println(
                    "Note          : Under-20 BMI needs age-specific interpretation."
            );
        } else if (bmi < 18.5) {
            System.out.println("BMI Category  : Underweight");
        } else if (bmi < 25) {
            System.out.println("BMI Category  : Normal");
        } else if (bmi < 30) {
            System.out.println("BMI Category  : Overweight");
        } else {
            System.out.println("BMI Category  : Obese");
        }

        System.out.println(
                "BMI is a screening measure, not a diagnosis."
        );
        System.out.println("=====================================");
    }
}

// ================= WORKOUT CLASS =================

class Workout {

    private String exerciseName;
    private int duration;
    private int caloriesBurned;
    private int steps;
    private LocalDate date;

    public Workout(String exerciseName,
                   int duration,
                   int caloriesBurned,
                   int steps,
                   LocalDate date) {
        this.exerciseName = exerciseName;
        this.duration = duration;
        this.caloriesBurned = caloriesBurned;
        this.steps = steps;
        this.date = date;
    }

    public int getDuration() {
        return duration;
    }

    public int getCaloriesBurned() {
        return caloriesBurned;
    }

    public int getSteps() {
        return steps;
    }

    public String getExerciseName() {
        return exerciseName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void displayWorkout() {
        System.out.println(
                "Date: " + (date == null ? "Unknown" : date) +
                " | Exercise: " + exerciseName +
                " | Duration: " + duration + " min" +
                " | Calories: " + caloriesBurned + " kcal" +
                " | Steps: " + steps
        );
    }
}

// ================= MAIN CLASS =================

public class PersonalizedFitnessTracker {

    static Scanner scanner = new Scanner(System.in);
    private static final Path DATA_FILE =
            Path.of("fitness-data.properties");
    static User user;
    static ArrayList<Workout> workouts = new ArrayList<>();

    public static void main(String[] args) {

        System.out.println("==========================================");
        System.out.println("      PERSONALIZED FITNESS TRACKER");
        System.out.println("==========================================");

        try {
            if (loadData()) {
                System.out.println("Saved profile and workouts loaded.");
            } else {
                createProfile();
                saveData();
            }
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("Could not load saved data: " + e.getMessage());
            return;
        }

        int choice;

        do {
            displayMenu();
            choice = getInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    user.displayProfile();
                    break;

                case 2:
                    addWorkout();
                    break;

                case 3:
                    viewWorkoutHistory();
                    break;

                case 4:
                    viewProgress();
                    break;

                case 5:
                    System.out.println(
                            "\nThank you for using " +
                            "Personalized Fitness Tracker!"
                    );
                    saveData();
                    break;

                default:
                    System.out.println(
                            "\nInvalid choice. " +
                            "Please select a number from 1 to 5."
                    );
            }

        } while (choice != 5);

        scanner.close();
    }

    // ================= CREATE PROFILE =================

    public static void createProfile() {

        System.out.println("\n========== CREATE PROFILE ==========");

        String name;

        while (true) {
            System.out.print("Enter your name: ");
            name = scanner.nextLine().trim();

            if (!name.isEmpty()) {
                break;
            }

            System.out.println("Name cannot be empty.");
        }

        int age;

        while (true) {
            age = getInt("Enter your age: ");

            if (age >= 10 && age <= 100) {
                break;
            }

            System.out.println(
                    "Please enter an age between 10 and 100."
            );
        }

        double weight;

        while (true) {
            weight = getDouble("Enter your weight (kg): ");

            if (weight > 0 && weight <= 500) {
                break;
            }

            System.out.println("Please enter a valid weight.");
        }

        double height;

        while (true) {
            height = getDouble("Enter your height (cm): ");

            if (height > 50 && height <= 250) {
                break;
            }

            System.out.println("Please enter a valid height.");
        }

        System.out.println("\nSelect your fitness goal:");
        System.out.println("1. Weight Loss");
        System.out.println("2. Muscle Gain");
        System.out.println("3. General Fitness");
        System.out.println("4. Improve Endurance");

        int goalChoice;

        while (true) {
            goalChoice = getInt("Choose an option: ");

            if (goalChoice >= 1 && goalChoice <= 4) {
                break;
            }

            System.out.println(
                    "Please select an option from 1 to 4."
            );
        }

        String goal;

        switch (goalChoice) {
            case 1:
                goal = "Weight Loss";
                break;
            case 2:
                goal = "Muscle Gain";
                break;
            case 3:
                goal = "General Fitness";
                break;
            case 4:
                goal = "Improve Endurance";
                break;
            default:
                goal = "General Fitness";
        }

        user = new User(
                name,
                age,
                weight,
                height,
                goal
        );

        System.out.println("\nProfile created successfully!");
    }

    // ================= MENU =================

    public static void displayMenu() {

        System.out.println("\n========== MAIN MENU ==========");

        System.out.println("1. View Fitness Profile");
        System.out.println("2. Add Workout");
        System.out.println("3. View Workout History");
        System.out.println("4. View Fitness Progress (all-time, today, last 7 days)");
        System.out.println("5. Exit");

        System.out.println("===============================");
    }

    // ================= ADD WORKOUT =================

    public static void addWorkout() {

        System.out.println("\n========== ADD WORKOUT ==========");

        String exerciseName;

        while (true) {
            System.out.print("Enter exercise name: ");
            exerciseName = scanner.nextLine().trim();

            if (!exerciseName.isEmpty()) {
                break;
            }

            System.out.println("Exercise name cannot be empty.");
        }

        int duration;

        while (true) {
            duration = getInt("Enter duration (minutes): ");

            if (duration > 0 && duration <= 1000) {
                break;
            }

            System.out.println("Please enter a valid duration.");
        }

        int calories;

        while (true) {
            calories = getInt("Enter calories burned: ");

            if (calories >= 0 && calories <= 10000) {
                break;
            }

            System.out.println(
                    "Please enter a valid calorie value."
            );
        }

        int steps;

        while (true) {
            steps = getInt("Enter steps completed: ");

            if (steps >= 0 && steps <= 100000) {
                break;
            }

            System.out.println(
                    "Please enter a valid step count."
            );
        }

        Workout workout = new Workout(
                exerciseName,
                duration,
                calories,
                steps,
                LocalDate.now()
        );

        workouts.add(workout);
        saveData();

        System.out.println("\nWorkout added successfully!");
    }

    // ================= WORKOUT HISTORY =================

    public static void viewWorkoutHistory() {

        System.out.println(
                "\n========== WORKOUT HISTORY =========="
        );

        if (workouts.isEmpty()) {
            System.out.println(
                    "No workouts have been recorded yet."
            );
            return;
        }

        for (int i = 0; i < workouts.size(); i++) {
            System.out.print((i + 1) + ". ");

            workouts.get(i).displayWorkout();
        }

        System.out.println(
                "====================================="
        );
    }

    // ================= PROGRESS =================

    public static void viewProgress() {

        System.out.println(
                "\n========== FITNESS PROGRESS =========="
        );

        if (workouts.isEmpty()) {
            System.out.println(
                    "No workout data available."
            );
            return;
        }

        long totalMinutes = 0;
        long totalCalories = 0;
        long totalSteps = 0;
        int todayWorkoutCount = 0;
        long todayMinutes = 0;
        long todayCalories = 0;
        long todaySteps = 0;
        int weekWorkoutCount = 0;
        long weekMinutes = 0;
        long weekCalories = 0;
        long weekSteps = 0;
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.minusDays(6);
        boolean hasUndatedWorkouts = false;

        for (Workout workout : workouts) {
            totalMinutes += workout.getDuration();
            totalCalories += workout.getCaloriesBurned();
            totalSteps += workout.getSteps();

            LocalDate workoutDate = workout.getDate();
            if (workoutDate == null) {
                hasUndatedWorkouts = true;
                continue;
            }

            if (workoutDate.equals(today)) {
                todayWorkoutCount++;
                todayMinutes += workout.getDuration();
                todayCalories += workout.getCaloriesBurned();
                todaySteps += workout.getSteps();
            }

            if (!workoutDate.isBefore(weekStart)
                    && !workoutDate.isAfter(today)) {
                weekWorkoutCount++;
                weekMinutes += workout.getDuration();
                weekCalories += workout.getCaloriesBurned();
                weekSteps += workout.getSteps();
            }
        }

        System.out.println("----- All-Time -----");
        System.out.println(
                "Total Workouts : " + workouts.size()
        );

        System.out.println(
                "Total Duration : " + totalMinutes + " minutes"
        );

        System.out.println(
                "Total Calories : " + totalCalories + " kcal"
        );

        System.out.println(
                "Total Steps    : " + totalSteps
        );

        System.out.println("----- Today (" + today + ") -----");
        printPeriodTotals(
                todayWorkoutCount, todayMinutes, todayCalories, todaySteps
        );

        System.out.println("----- Last 7 Days -----");
        System.out.println(
                "Period         : " + weekStart + " to " + today
        );
        printPeriodTotals(
                weekWorkoutCount, weekMinutes, weekCalories, weekSteps
        );

        if (hasUndatedWorkouts) {
            System.out.println(
                    "Some older saved workouts have no date and are included "
                            + "only in all-time totals."
            );
        }

        System.out.println(
                "Fitness Goal   : " + user.getFitnessGoal()
        );

        System.out.println(
                "======================================"
        );
    }

    private static void printPeriodTotals(
            int workoutCount,
            long minutes,
            long calories,
            long steps
    ) {
        System.out.println("Workouts       : " + workoutCount);
        System.out.println("Duration       : " + minutes + " minutes");
        System.out.println("Calories       : " + calories + " kcal");
        System.out.println("Steps          : " + steps);
    }

    private static void saveData() {
        Properties data = new Properties();

        data.setProperty("user.name", user.getName());
        data.setProperty("user.age", Integer.toString(user.getAge()));
        data.setProperty("user.weight", Double.toString(user.getWeight()));
        data.setProperty("user.height", Double.toString(user.getHeight()));
        data.setProperty("user.goal", user.getFitnessGoal());
        data.setProperty("workout.count", Integer.toString(workouts.size()));

        for (int i = 0; i < workouts.size(); i++) {
            Workout workout = workouts.get(i);
            String prefix = "workout." + i + ".";

            data.setProperty(prefix + "name", workout.getExerciseName());
            data.setProperty(prefix + "duration",
                    Integer.toString(workout.getDuration()));
            data.setProperty(prefix + "calories",
                    Integer.toString(workout.getCaloriesBurned()));
            data.setProperty(prefix + "steps",
                    Integer.toString(workout.getSteps()));
            if (workout.getDate() != null) {
                data.setProperty(prefix + "date",
                        workout.getDate().toString());
            }
        }

        try (OutputStream output = Files.newOutputStream(DATA_FILE)) {
            data.store(output, "Fitness tracker saved data");
        } catch (IOException e) {
            System.out.println("Could not save data: " + e.getMessage());
        }
    }

    private static boolean loadData() throws IOException {
        if (!Files.exists(DATA_FILE)) {
            return false;
        }

        Properties data = new Properties();

        try (InputStream input = Files.newInputStream(DATA_FILE)) {
            data.load(input);
        }

        user = new User(
                requiredProperty(data, "user.name"),
                Integer.parseInt(requiredProperty(data, "user.age")),
                Double.parseDouble(requiredProperty(data, "user.weight")),
                Double.parseDouble(requiredProperty(data, "user.height")),
                requiredProperty(data, "user.goal")
        );

        int workoutCount = Integer.parseInt(
                requiredProperty(data, "workout.count")
        );

        if (workoutCount < 0) {
            throw new IllegalArgumentException("Invalid workout count.");
        }

        workouts.clear();

        for (int i = 0; i < workoutCount; i++) {
            String prefix = "workout." + i + ".";
            String savedDate = data.getProperty(prefix + "date");
            LocalDate workoutDate = savedDate == null
                    ? null
                    : LocalDate.parse(savedDate);

            workouts.add(new Workout(
                    requiredProperty(data, prefix + "name"),
                    Integer.parseInt(
                            requiredProperty(data, prefix + "duration")),
                    Integer.parseInt(
                            requiredProperty(data, prefix + "calories")),
                    Integer.parseInt(
                            requiredProperty(data, prefix + "steps")),
                    workoutDate
            ));
        }

        return true;
    }

    private static String requiredProperty(Properties data, String key) {
        String value = data.getProperty(key);

        if (value == null) {
            throw new IllegalArgumentException(
                    "Saved data is missing: " + key
            );
        }

        return value;
    }

    // ================= INTEGER INPUT =================

    public static int getInt(String message) {

        while (true) {
            System.out.print(message);

            String input = scanner.nextLine().trim();

            try {
                return Integer.parseInt(input);

            } catch (NumberFormatException e) {
                System.out.println(
                        "Invalid input. " +
                        "Please enter a whole number."
                );
            }
        }
    }

    // ================= DOUBLE INPUT =================

    public static double getDouble(String message) {

        while (true) {
            System.out.print(message);

            String input = scanner.nextLine().trim();

            try {
                return Double.parseDouble(input);

            } catch (NumberFormatException e) {
                System.out.println(
                        "Invalid input. " +
                        "Please enter a number."
                );
            }
        }
    }
}
